%% this file enables all buttons

set(accept, 'Enable', 'on');
set(slider, 'Enable', 'on')
set(skipbut, 'Enable', 'on');
set(view0, 'Enable', 'on');
set(view20, 'Enable', 'on');
set(view40, 'Enable', 'on');
set(view60, 'Enable', 'on');
set(view80, 'Enable', 'on');
set(view100, 'Enable', 'on');
drawnow;