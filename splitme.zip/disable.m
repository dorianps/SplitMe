%% this file disable all buttons

set(accept, 'Enable', 'off');
set(slider, 'Enable', 'off')
set(skipbut, 'Enable', 'off');
set(view0, 'Enable', 'off');
set(view20, 'Enable', 'off');
set(view40, 'Enable', 'off');
set(view60, 'Enable', 'off');
set(view80, 'Enable', 'off');
set(view100, 'Enable', 'off');
drawnow;